#EJERCICIO
print("Me encanta estudiar phyton")
print('Estudiar con "Phyton Total" es super divertido')
print(500+55)
