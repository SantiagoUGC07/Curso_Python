#EJERCICIOS
print("1 | lìnea 1\n2 | lìnea 2\n3 | línea 3")
print("1 | A  B\tC\n2 | D  E\tF\n3 | G  H\tI")
print("1 | Barra Normal: /\n2 | Barra invertida: \\ ")
