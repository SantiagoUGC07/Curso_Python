#1 - COMO IMPRIMIR EN PHYTON
print("Hola Mundo te digo")
#COMENTARIO SE USA #
#2 - INTEGRAR COMILLAS "" a una impresion
print("Hola Mundo te digo 'hola' ")
print("Hola Mundo te digo 10+5" )
#3 - IMPRIMIR OPERACIONES
print(50+50)
print(50)