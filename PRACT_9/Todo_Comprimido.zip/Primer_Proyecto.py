#tomar dos preguntas y decir cual es nombre de la cerveza
print("La cerveza se llama: \n" + input("¿Cual es tu animal favorito?") + " " + input("\n¿Dime que color te gusta?"))



