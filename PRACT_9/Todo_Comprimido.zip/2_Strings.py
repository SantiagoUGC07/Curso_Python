#1 - Strings Son cadenas de texto
print('100 + 50')
#2 - Cadenas de texto unir con simbolo +
print("Hola" + " " + 'Uriel')
#3 - barra invertida, le dice a phyton que es siguiente caracter es un caracter especial
#de esta manera puedes colocar comillas dentro de comillas
print("me llamo \"Santiago\" ")
#4 - para dar salto de line usar \n
print("Esta es una linea \ny esta es otra linea")
#5 - para tener un tabulador \t
print("\tse tiene una tabulacion")
#6 - TRUCOS PARA ESCRIBIR APOSTROFE
print ('Esta es i can\'t ')
#7 - para colocolar una barra invertida se pone una barra invertida despues
print('Este signo \\ es una barra invertida')


