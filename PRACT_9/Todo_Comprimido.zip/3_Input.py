#para imprimir lo que ingrese el usuario

#1 - AGREGANDO INPUT, no ejecuta el final del programa hasta que se agrega la info.
#input("Dime tu nombre: ")

#2 - Phyton ejecutara de adentro hacia afuera
#print(input("Dime tu nombre: "))

#3 - para imprimir el nombre con texto
print("Tu nombre es: " + input("Dime tu nombre: ") + "\nTu apellido es: " + input("Dime tu apellido: "))
