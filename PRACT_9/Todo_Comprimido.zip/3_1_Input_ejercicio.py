#EJERCICIO 1
print(input("¿Qué estás estudiando? "))
#EJERCICIO 2
print(input("¿En qué país vives?"))
#EJERCICIO 3
print(input(" | Escribre tu nombre:  ") + " " + input("\nEscribe tu apellido: "))
